//Main class would be responsible for starting the game
public class Main {
	
	public static void main (String[] args) {
		System.out.println("This is only a demonstration of a possible structure for a Gorilla game");
	}

}
